(function( $, undefined ) {

	var h = $(window).height(),
		w = $(window).width(),
		u = {
			//'test_device_platform': 'http://218.206.191.82/webapps/test_device/test_device_platform',
			//'test_device_boss': 'http://218.206.191.82/webapps/test_device/test_device_boss'
            'test_device_platform': 'method=cmcc.ecip.internal.mext.device.platform',
            'test_device_boss': 'method=cmcc.ecip.internal.mext.device.boss'
		},
		d = {},
        arr={},
		dailyDate = {};
	var merger;
	$.ajaxData = function( options ) {
		var defaults = {
			url: null,
			type: 'POST',
			data: {},
			dataType: 'json',
			onSuccess: function( data ){},
			onFail: function(){}
		};

		var settings = $.extend( {}, defaults, options );

		$.ajax({
            url: settings.url,
            type: settings.type,
            data: settings.data,
            dataType: settings.dataType,
            timeout: 120000
        })
        .done(function( data ){
            settings.onSuccess.call( this, data );
        })
        .fail(function( jqXHR, textStatus, errorThrown){
            settings.onFail.call( this,jqXHR, textStatus, errorThrown );
        });

    };

	$.loadData = function( options ){
		var defaults = {
			onSuccess: function(){}
		};
		var settings = $.extend( {}, defaults, options ),
			dataCount = 0,
			merger =dailyDate.y.toString() + dailyDate.m.toString() + dailyDate.d.toString(),
			loadStatus = true;

            var urlme=permission(u);

        $.each(u, function( i, item ) {
			$.ajaxData({
				url:item,
				onSuccess: function( data ){
					d[ i ] = data;
					dataCount = dataCount + 1;
					$('.load-img').html( dataCount * 48 + '%' );
					if( dataCount == 2 ){
						$( '#page' ).data('status', 'success');
						settings.onSuccess.call( this );
					};
				},
				onFail: function(jqXHR, textStatus, errorThrown){
                    if( loadStatus == true ){
						loadStatus = false;
						$( '#page' ).data('status', 'error');
						settings.onFail.call( this );
					};
				}
			});
		});
	};

	$.getItemData = function( options ){
		var defaults = {
			data: {}
		};

		var settings = $.extend( {}, defaults, options ),
			_data = {},
			_i = 0;

		$.each(settings.data, function( i, item ) {
			if( item.hparty_id == settings.id ){
				_data[ _i ] = item;
				_i++;
			};
		});
		return _data;
	};

	$.dailyInit = function( options ) {
		var defaults = {};

		var settings = $.extend( {}, defaults, options ),
			date = new Date();

		dailyDate.y = date.getFullYear();
		dailyDate.m = date.getMonth() + 1;
		dailyDate.d = date.getDate() - 1;
		if( dailyDate.d<10 ){ dailyDate.d='0'+dailyDate.d };
		if( dailyDate.m<10 ){ dailyDate.m='0'+dailyDate.m };
        merger = dailyDate.y.toString() + dailyDate.m.toString() + dailyDate.d.toString();
		$( '#page' ).pageControl({
			page: 1,
			loading: true,
			first: true
		});
	};

	$.fn.pageControl = function( options ){
		var defaults = {
			page: 1,
			loading: false,
			first: false
		};

		var settings = $.extend( {}, defaults, options ),
			elems = this;
		$.ajaxData({
			url: 'static/html/'+ settings.page +'.html?' + Math.random(),
			type: 'GET',
			dataType: 'html',
			onSuccess: function( data ){
				$( elems ).html( data ).data( 'page', settings.page );
				switch( settings.page ){
					case 1:
						pageIndex( settings.loading, settings.first );
						break;
					case 2:
						pageRate();
						break;
					case 3:
						pageDetail();
						break;
					case 4:
						goSearchModule();
						break;
				};
			}
		});
		function pageIndex( loading, first ){
			var loadingString = '<div id="loadData"><div class="load-img">0%</div></div>';

			$( '#summaryTabs' ).delegate('span','click',function() {
				$( this ).addClass( 'current' ).siblings().removeClass( 'current' );
				var _index = $(this).index();
				$('.tab-detail .tab-content>.tab-cont').hide().eq(_index).show();
				$( '#page' ).data({
					'tabIndex':_index
				});
				sScroll.refresh();
			});
			
            $( document ).on('click', '#reload', load);
            
            if( loading == true ){
				load();
			}else{
				render();
			}
            
            function load() {
                $( '#errBox' ).detach();
                $( 'header' ).after( loadingString );
                $.loadData({
                    onSuccess: function(){
                        $( '#loadData' ).detach();
                        if( first == true ){
                            //onExit();
                        };
                        render();
                    },
                    onFail: function(){
                        $( '#loadData' ).detach();
                        render();
                   }
                });
            }
            function render(){
            	var err1 = '<div id="errBox" class="err"><div class="err-img"><img src="static/images/icon_err1.png" alt="" /></div><div class="err-txt">网络连接异常</div></div>',
					err2 = '<div id="errBox" class="err"><div class="err-img"><img src="static/images/icon_err2.png" alt="" /></div><div class="err-txt">当前日期暂无数据</div></div>';
				//$('#summaryList .tab-detail .tab-content').html('');

                $("#exit").click(function(){

                    //document.addEventListener("exit", onBackKey, false);
                    //function onBackKey() {
                        navigator.app.exitApp();
                    //}
                    alert("b");
                });
				function formateData(data,_type){
                    var li = '';
                    if(data.code="00000"){
                        $.each(data.result,function(m,n){
                            //alert(jsondata.result);
                            li += [
                                '<li>',
                                '<div class="list-box cf">',
                                '<div class="name cf">',
                                _type == 0 ? '<div class="icon-plateform"><img src="static/images/icon/'+n.party_id+'.png" /></div>' : '',
                                '<div class="title-plateform'+(_type == 1?' no-margin':'')+'">',
                                '<p>'+n.party_name+'</p>',
                                '<p>'+n.party_id+'</p>',
                                '</div>',
                                '</div>',
                                '<div class="ip">',
                                '<p>端口:'+n.port+'</p>',
                                '<p>IP:'+n.ip+'</p>',
                                '</div>',
                                '</div>',
                                '<div class="detail-box">',
                                '<p>内网：'+n.ip1+'</p>',
                                n.ip_3?'<p>外网：'+n.ip2+'</p><p>管理：'+n.ip_3+'</p>':'<p>管理：'+n.ip2+'</p>',
                                '</div>',
                                '</li>'
                            ].join('');
                        });
                    }else{
                        li = [
                            '<li><p>'+data.des+"["+data.code+"]"+'</p></li>'
                        ].join('');
                    }

					var tabIndex = $('#tabDetail .tab-content>.tab-cont:eq('+_type+')');
					tabIndex.html(li);
					tabIndex.find('li').bind('mouseup',function(){
						var _detail = $(this).find('.detail-box');
						if(_detail.is(':visible')){
							_detail.slideUp(150,function(){sScroll.refresh();});
						}else{
							$('#tabDetail .tab-cont li .detail-box').hide();
							_detail.slideDown(150,function(){sScroll.refresh();});
						}
					});
				}
				formateData(d.test_device_platform,0);
				formateData(d.test_device_boss,1);

				$( '#tabDetail' ).height( h - $( '#tabDetail' ).offset().top );
				sScroll.refresh();
				return;
				if( $( '#page' ).data('status') == 'success' ){
					if( d.mechanism.length > 0 ){

		            }else{
		                $( 'header' ).after( err2 );
		            };
				}else{
					$( 'header' ).after( err1 );
				}
            };
            function onExit() {
	            document.addEventListener("backbutton", onBackKey, false);
                document.addEventListener("exit", onBackKey, false);
	            function onBackKey(){
	                switch ($('#page').data('page')) {
	                    case 1:
                            alert("a");
	                        navigator.app.exitApp();
                            alert("b");
	                        break;
	                    case 2:
	                        $( '#page' ).removeData('page');
	                        $( '#page' ).pageControl({
	                            page: 1
	                        });
	                        break;
	                    case 3:
	                        if( typeof($( '#page' ).data( 'itemCode' )) == 'string' ){
	                            $( '#page' ).removeData( 'itemCode' );
	                        };
	                        $( '#page' ).pageControl({
	                            page: 2
	                        });
	                        break;
	                }
	            }
	        }
		};
	};

})( jQuery );

$(document).ready(function() {
    $.dailyInit();
});