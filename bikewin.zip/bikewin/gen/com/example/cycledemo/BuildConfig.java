/** Automatically generated file. DO NOT MODIFY */
package com.example.cycledemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}